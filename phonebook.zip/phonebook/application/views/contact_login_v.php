<!DOCTYPE html>
<html>
	<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<title>Phonebook</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    </head>
	<body>


<section class="vh-100">
  <div class="container py-5 h-100">
    <div class="row d-flex justify-content-center align-items-center h-100">
      <div class="col-12 col-md-8 col-lg-6 col-xl-5">
        <div class="card shadow-2-strong" style="border-radius: 1rem; background-color: #C0C0C0;">
          <div class="card-body p-5 text-center">

            <h3 class="mb-5">Sign in</h3>

            <form action="<?php echo base_url('login/login_now/')?>" method="post">

            <div class="form-outline mb-4">
              <input type="text" id="type_username" name="username" class="form-control form-control-lg" placeholder="Username" />
            </div>

            <div class="form-outline mb-4">
              <input type="password" id="type_password" name="password" class="form-control form-control-lg" placeholder="Password"/>
            </div>

            <!--begin::Input group-->
						<div class="form-outline mb-4">
							<!--begin::Col-->
							<div class="col-md-6 fv-row">
								<select id="type_user" class="form-select" name="user_type">
                   <option value="" disabled selected>Select User</option>
                   <option value="admin">Admin</option>
                   <option value="user">User</option>
                </select>
							</div>
							<!--end::Col-->
						</div>
						<!--end::Input group-->

            <!-- Checkbox -->
            <div class="form-check d-flex justify-content-start mb-4">
              <input class="form-check-input" type="checkbox" value="" id="form1Example3" />
              <label class="form-check-label" for="form1Example3">Remember password </label>
            </div>

            <button class="btn btn-primary btn-lg btn-block" type="submit" name="">Login</button></br></br>

            <div class="form-outline mb-4">
              <label class="form-check-label" for="form1Example3">Forget Password?</label>
              <a href="<?php echo base_url('forget_password/forget/') ?>">Click here</a></br>

              <label class="form-check-label" for="form1Example3">Not Registered?</label>
              <a href="<?php echo base_url('register/contact_register/') ?>">Register here</a>
            </div>

            <!--message error-->
            <?php
						if($this->session->flashdata('error')) {	?>
						 <p class="text-danger text-center" style="margin-top:10px;"> <?=$this->session->flashdata('error')?></p>
						<?php } ?>
            </form>

          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- Option 1: Bootstrap Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</body>
</html>