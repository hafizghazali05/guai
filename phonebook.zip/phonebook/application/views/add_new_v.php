<!DOCTYPE html>
<html>
	<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<title>Add Phonebook</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>    
<style>
	.error{color:red}
</style>

</head>
	<body>

<div class="container py-5 h-100">
  <div class="row d-flex justify-content-center align-items-center h-100">
   <div class="col-12 col-md-7">
   <div class="card shadow-2-strong" style="border-radius: 1rem;">
     <div class="card-body p-5">

        <form action="<?php echo base_url('home/add_contact_save')?>" method="post">
    
	    <div class="mb-3">
	       <label class="required fs-6 fw-bold mb-2">Contact Name</label>
	       <input type="text" class="form-control" placeholder="Name" id="txt_name" name="txt_name"/>
		   <?php echo form_error('txt_name'); ?>
        </div>
	       
	    <div class="mb-3">
	       <label class="required fs-6 fw-bold mb-2">Contact Number</label>
	       <input type="text" class="form-control" placeholder="Phone No." id="txt_phone" name="txt_phone"/>
		   <?php echo form_error('txt_phone'); ?>
        </div></br>
           
           <button type="submit" class="btn btn-primary">Save</button> <a href="<?php echo base_url('/home/listing/') ?>" class="btn btn-secondary">Back</a>
        
	    </form>

	   </div>
	  </div>
	</div>
  </div>
</div>


	</body>
</html>