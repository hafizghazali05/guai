<?php 
if($this->session->userdata('UserLoginSession'))
{
    $udata = $this->session->userdata('UserLoginSession');
    //echo 'Welcome'.' '.$udata['username'].'! ('.$udata['user_type'].')';
}
else
{
    redirect(base_url('login/contact_login/'));
}

?>


<!DOCTYPE html>
<html>
	<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<title>Phonebook</title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">

	<style>
      .f-l {
          float: left;
      }
          
      .f-r {
          float: right;
      }
	</style>
    
    </head>
	<body>
	
	<div class="container py-5 h-100">
      <div class="row d-flex justify-content-center align-items-center h-100">
       <div class="col-12 col-md-8">
	    <div class="card shadow-2-strong" style="border-radius: 1rem;">
        <div class="card-body p-5">
		
		
		<div class="row justify f-l">
		  <form action="<?php echo base_url('home/upload_excel/') ?>" method="post">  
		    <div class="input-group mb-3">
		       <button class="btn btn-primary"><i class="fas fa-upload mr-1"></i>Upload Excel</button>
	        </div>	      
		  </form>
	    </div>

		<div class="row justify-content-end">
		 <div class="col-md-6">

		   <form action="<?php echo base_url('home/search/') ?>" method="post">
		   <div class="input-group mb-3">
              <input type="text" class="form-control" placeholder="Search.." name="keyword" autocomplete="off" value="<?php echo isset($keyword) ? $keyword : ''?>">
              <div class="input-group-append">
                <input class="btn btn-primary" type="submit" name="submit" value="Search">
              </div>
            </div>
           </form>

          </div>
        </div>

		<?php if(empty($query->result())){?>
           <div class="alert alert-danger" role="alert">
		   <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
            Contact List Not Found.
           </div>
        <?php }?>

		</br>
		
		<?= $this->session->flashdata('message');?>
	    
			<table class="table">
	     <tr>
	    	 <td><b>#</b></td>
	    	 <td><b>Name</b></td>
	    	 <td><b>Phonebook</b></td>
	    	 <td><b>Action</b></td>
	     </tr>
	     <?php
			foreach($query->result() as $row) {
		?>
	     <tr>
	         <td><b><?php echo ++$start; ?></b></td>
	    	 <td><?php echo $row->txt_name ?></td>
	    	 <td><?php echo $row->txt_phone ?></td>
	    	 <td><a href="<?php echo base_url('/home/edit_contact') ?>/<?php echo $row->id ?>" class="btn btn-warning">Edit</a>&nbsp;<a href="<?php echo base_url('/home/delete_phonebook') ?>/<?php echo $row->id ?>" class="btn btn-danger" onclick="return confirm('Are you sure to delete this user?')">Delete</a></td>
	     </tr>
	     <?php 
		    
		 }?>
         </table>

		 <?php echo $pagination?></br>
	
	     <a href="<?php echo base_url('/home/add_contact') ?>" class="btn btn-success">Add New</a></br></br>
		 <a href="<?php echo base_url('/home/logout') ?>"><i class="fas fa-sign-out-alt"></i></a>
		 
    	 </div>
      </div> 
	</div>
  </div>
</div>



<script type="text/javascript">
function delete_user(user_id) 
//{
//	onclick="delete_user(<?php //echo $row->id ?>);
//	if(confirm("Are you sure to delete this user?")) 
//	{
//	    $('#remove_user_id').val(user_id);
//	}
//}
</script>


     <script src="https://use.fontawesome.com/releases/v5.0.8/js/all.js" integrity="sha384-SlE991lGASHoBfWbelyBPLsUlwY1GwNDJo3jSJO04KZ33K2bwfV9YBauFfnzvynJ" crossorigin="anonymous"></script>
	 <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
     <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.3/dist/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
     <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
    </body>
</html>