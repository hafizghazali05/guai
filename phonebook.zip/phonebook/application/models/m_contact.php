<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class m_contact extends CI_Model {

    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }

	//pagination function
    function contact_listing()
    {
		$query = $this->db->query("SELECT * FROM tbl_phonebook");
		$data['total_rows'] = $query->num_rows();

		$config['base_url'] = base_url() . 'home/listing/';
		$config['uri_segment'] = 3;
        $config['total_rows'] = $data['total_rows'];
        $config['per_page'] = 3;
        
        $this->pagination->initialize($config);

		$data['pagination'] = $this->pagination->create_links();

		//count rows
		$data['start'] = $this->uri->segment(3);

		$sql = '';
		if($data['total_rows'] > 0) {
			if($this->uri->segment($config['uri_segment']) && is_numeric($this->uri->segment($config['uri_segment'])))
			{
				$sql = ' LIMIT ' . $this->uri->segment($config['uri_segment']) . ', ' . $config['per_page'];
			}
			else
			{
				$sql = ' LIMIT 0, ' . $config['per_page'];
			}
		}
		
		$data['query'] = $this->db->query("SELECT * FROM tbl_phonebook ORDER BY id DESC $sql");

		return $data;
    }

    //search function
    function search_contact($keyword64)
	{
	    $post = json_decode(base64_decode($keyword64));

		//print_r($post);
		//die;
	    
	    $where_sql = '';

	    if($post != '') {
		    $where_sql .= " AND txt_name LIKE " . $this->db->escape('%' . $post . '%') ." OR txt_phone LIKE " . $this->db->escape('%' . $post . '%');
	    }

		$query = $this->db->query("SELECT * FROM tbl_phonebook WHERE 1 $where_sql");
		$data['total_rows'] = $query->num_rows();

		//pagination
		$config['base_url'] = base_url() . 'home/search/' . $keyword64 . '/';
		$config['uri_segment'] = 4;
		$config['total_rows'] = $data['total_rows'];
		$config['per_page'] = 3;
        
        $this->pagination->initialize($config);

		$data['pagination'] = $this->pagination->create_links();

		//count rows
		$data['start'] = $this->uri->segment(4);

		$sql = '';

		if($data['total_rows'] > 0) {
			if($this->uri->segment($config['uri_segment']) && is_numeric($this->uri->segment($config['uri_segment'])))
			{
				$sql = ' LIMIT ' . $this->uri->segment($config['uri_segment']) . ', ' . $config['per_page'];
			}
			else
			{
				$sql = ' LIMIT 0, ' . $config['per_page'];
			}
		}
		
		$data['query'] = $this->db->query("SELECT * FROM tbl_phonebook WHERE 1 $where_sql ORDER BY id DESC $sql");

		return $data;
	}

	function excel()
	{
		if(isset($_FILES["file"]["name"])){
			
			//xls upload
			$file_tmp = $_FILES['file']['tmp_name'];
			$file_name = $_FILES['file']['name'];
			$file_size =$_FILES['file']['size'];
			$file_type=$_FILES['file']['type'];
			//move_uploaded_file($file_tmp,"uploads/".$file_name); // save uploaded xls file
			
			$object = PHPExcel_IOFactory::load($file_tmp);
	
			foreach($object->getWorksheetIterator() as $worksheet){
	
				$highestRow = $worksheet->getHighestRow();
				$highestColumn = $worksheet->getHighestColumn();
	
				for($row=2; $row<=$highestRow; $row++){
	
					$txt_name = $worksheet->getCellByColumnAndRow(0, $row)->getValue();
					$txt_phone = $worksheet->getCellByColumnAndRow(1, $row)->getValue();

					$data[] = array(
						'txt_name'  => $txt_name,
						'txt_phone' =>$txt_phone,
					);
				} 
			}
	
			$this->db->insert_batch('tbl_phonebook', $data);
	
			$message = array(
				'message'=>'<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Successfully uploaded</div>',
			);
			
			$this->session->set_flashdata($message);
			redirect('home/listing');
		}
		else
		{
			 $message = array(
				'message'=>'<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Uploaded failed, please try again!</div>',
			);
			
			$this->session->set_flashdata($message);
			redirect('home/upload_excel');
		}
	}

	//insert data
    function insert_phonebook($data){
        
        $this->db->insert('tbl_phonebook', $data);
		$message = array(
			'message'=>'<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Successfully added</div>',
		);
		
		$this->session->set_flashdata($message);
    }

	//contact detail
    function get_phonebook_detail($id){

        $this->db->where('id' , $id);

        $query = $this->db->get('tbl_phonebook');

        return $query->row();

    }

    //update data
    function update_phonebook_detail($id, $data){

        $this->db->where('id' , $id);
        $this->db->update('tbl_phonebook' , $data);

		$message = array(
			'message'=>'<div class="alert alert-info"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Successfully update</div>',
		);
		
        $this->session->set_flashdata($message);
    }
    
	//delete data
    function delete_phonebook_detail($id){
        
        $this->db->where('id' , $id);
        $this->db->delete('tbl_phonebook');

		$message = array(
			'message'=>'<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Successfully delete</div>',
		);
		
		$this->session->set_flashdata($message);
    }

	//validate login
    function check_password($password, $username, $user_type)
	{
		$query = $this->db->query("SELECT * FROM contact_user WHERE password='$password' AND username='$username' AND user_type='$user_type'");

        //restricted user = 'admin'
		if($user_type=='admin')
		{
			//restricted 1 user login
			if($query->num_rows()==1)
			{
                //set timezone Asia
                date_default_timezone_set("Asia/Kuala_Lumpur");

                $this->db->update('contact_user', array('last_login'=>date('Y-m-d H:i:s')));
				return $query->row();
			}
			else
			{
				return false;
			}
		}

	}

    //register user
    function insert_user($data)
	{
		$this->db->insert('contact_user', $data);
	}

    //forget password
    function update_user($username, $data)
	{
        $this->db->where('username', $username);
		$this->db->update('contact_user', $data);
	}


}
