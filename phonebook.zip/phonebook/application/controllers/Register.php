<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Register extends CI_Controller {

	public function __construct(){
    parent::__construct();
	$this->load->model('m_contact');

	}

	    //user register
		public function contact_register() //NOTE: bukak controller/Register.php
		{
			$this->load->view('contact_register_v');
		}

		public function register_now()
		{
			if($_SERVER['REQUEST_METHOD']=='POST')
			{
				//validation form
				$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
				$this->form_validation->set_rules('username','Username','trim|required|callback_checkUsername');
				$this->form_validation->set_rules('password','Password','required');
				$this->form_validation->set_rules('confirmed_password','Confirmed Password','required|matches[password]');
				$this->form_validation->set_rules('user_type','User Type','required');
				$this->form_validation->set_message('required', '{field} must be filled');

				if($this->form_validation->run()==TRUE)
				{
					$username = $this->input->post('username');
					$password = $this->input->post('password');
					$confirmed_password = $this->input->post('confirmed_password');
					$user_type = $this->input->post('user_type');

					//check password
					if($confirmed_password==$password)
					{
						$data = array(
							'username'=>$username,
							'password'=>md5($password),
							'user_type'=>$user_type
						);
		
						$this->m_contact->insert_user($data);
						echo "<script>alert('Sucessfully Registered!');</script>";

						//loading back to listing page
						$this->load->view('contact_login_v');

						//redirect('login/contact_login/');
					}  
				}
				else
				{
					$this->load->view('contact_register_v');
				}
			}
		}

		public function checkUsername($str)
		{
			//query username
			$this->db->select('username');
			$this->db->from('contact_user');
			$this->db->where('username', $str);

			$query = $this->db->get();

			//check username available
            if($query->num_rows() > 0)
            {
				$this->form_validation->set_message('checkUsername', 'Username already taken, please create new username');
				return false;
            }
			else
			{
               return true;
			}
		}
}
