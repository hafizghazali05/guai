<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	public function __construct(){
    parent::__construct();
	$this->load->model('m_contact');

	}

    //user login page
	public function contact_login() //NOTE: bukak controller baru controller/Login.php
	{
		$this->load->view('contact_login_v');
	}

	function login_now()
	{
		if($_SERVER['REQUEST_METHOD']=='POST')
		{
			//validation login
			$this->form_validation->set_rules('username','Username','required');
			$this->form_validation->set_rules('password','Password','required');
			$this->form_validation->set_rules('user_type','User Type','required');

			if($this->form_validation->run()==TRUE)
			{
				$username  = $this->input->post('username');
				$password  = $this->input->post('password');
				$user_type = $this->input->post('user_type');
				//$password = sha1($password);

				$this->load->model('m_contact');
				
				$status = $this->m_contact->check_password(md5($password), $username, $user_type);
				if($status!=false)
				{
					$username = $status->username;
					$user_type = $status->user_type;

					$session_data = array(
						'username'=>$username,
						'user_type'=>$user_type,
					);

					$this->session->set_userdata('UserLoginSession', $session_data);

					redirect(base_url('home/listing/'));
				}
				else
				{
					$this->session->set_flashdata('error','Please check username, password and user type');
					redirect(base_url('login/contact_login/'));
				}
			}
			else
			{
				$this->session->set_flashdata('error','Fill all the required fields');
				redirect(base_url('login/contact_login/'));
			}
		}
	}


	
}
