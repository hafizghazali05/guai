<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Forget_Password extends CI_Controller {

	public function __construct(){
    parent::__construct();
	$this->load->model('m_contact');

	}

	//reset user password
	public function forget()
	{
		$this->load->view('forget_password_v');
	}

	//find username
	function find_username()
	{
	    $this->form_validation->set_rules('username','Username','required');

		if($this->form_validation->run()==false)
		{
			$this->session->set_flashdata('error','Please enter your username');

			redirect(base_url('forget_password/forget/'));
		}
		else
		{
			$username = $this->input->post('username');

			$get_user = $this->db->get_where('contact_user', ['username' => $username])->row_array();

			if($get_user)
			{
			   $this->session->set_userdata('reset_username', $username);
			   $this->change_password();

			   redirect(base_url('forget_password/change_password/'));
			}
			else
			{
				$this->session->set_flashdata('error','Username not Registered!');

				redirect(base_url('forget_password/forget/'));
			}
		}
	}

    //change pasword page
	public function change_password()
	{
		$this->load->view('change_password_v');
	}

	//change password function
	function change_now()
	{
		if($_SERVER['REQUEST_METHOD']=='POST')
		{
			//set timezone: Asia
			date_default_timezone_set("Asia/Kuala_Lumpur");

			//validation password
			$this->form_validation->set_rules('password','Password','required');
			$this->form_validation->set_rules('confirmed_password','Confirmed Password','required');

			if($this->form_validation->run()==TRUE)
			{
				$username = $this->input->post('username');
				$password = $this->input->post('password');
				$confirmed_password = $this->input->post('confirmed_password');

				if($confirmed_password==$password)
				{
					$data = array(
						'username'=>$username,
						'password'=>md5($password),
						'last_login'=>date('Y-m-d H:i:s')
					);
	
					$this->m_contact->update_user($username, $data);
					$this->session->set_flashdata('success','Password Successfully Changed');

					redirect(base_url('login/contact_login/'));
				}
				else
				{
					$this->session->set_flashdata('error','Confirmed password and password not matched!');

					redirect(base_url('forget_password/change_password/'));
				}
			}
			else
			{
				$this->session->set_flashdata('error','Please fill in password!');

				redirect(base_url('forget_password/change_password/'));
			}
		}
	}


	
}
