<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	public function __construct(){
    parent::__construct();
	$this->load->model('m_contact');
	}

	public function index()
	{
		redirect('login/contact_login/');
	}

	public function listing()
	{
		$data = $this->m_contact->contact_listing();
		
		$this->load->view('home_v', $data); //NOTE: rename view/home_v.php
	}

	//NOTE: Bukak search baru, jgn share dgn listing kat atas
	public function search($keyword64 = null)
	{
		#Process the posted data, then redirect back to this function
		if($_POST) {
            
			#We Base64 Encode the search String, it's for safe url passing.
			$keyword = trim(base64_encode(json_encode($_POST['keyword'])), '=.');

			#Search button pressed with empty search string 
			if($keyword == '') 
				redirect("home/search/");
			else
				redirect("home/search/$keyword");
				
			exit();
		}
		
		if($keyword64 != null) {
			#Get the data from DB
			$data = $this->m_contact->search_contact($keyword64);
		}
		
		#Set the Title on top of the HTML
		$this->load->view('home_v', $data);
	}

	//upload phonebook excel page
	function upload_excel()
	{
		$this->load->view('upload_excel_v');
	}

	//upload xls file
	public function excel()
	{
		$this->m_contact->excel();
		
		//redirect(base_url('home/listing/'));
	}

   //add contact page
	public function add_contact()
	{
		$this->load->view('add_new_v');
	}

	//edit contact page
	public function edit_contact($id)
	{
		$queryAllContactDetail = $this->m_contact->get_phonebook_detail($id);
        $DATA = array('queryConDetails' => $queryAllContactDetail); 
		$this->load->view('edit_contact_v', $DATA);
	}

	//add contact function
	public function add_contact_save()
	{   
		if($this->input->post())
		{
			//form validation
           $this->form_validation->set_error_delimiters('<div class="error">', '</div>');
		   $this->form_validation->set_rules('txt_name', 'Contact Name', 'required');
		   $this->form_validation->set_rules('txt_phone', 'Phone Number', 'required');
		   $this->form_validation->set_message('required', '{field} must be filled');
		}

		if($this->form_validation->run()==TRUE)
		{
			$id = $this->input->post('id');
			$txt_name = $this->input->post('txt_name');
			$txt_phone = $this->input->post('txt_phone');
	
			$ArrInsert = array(
				'txt_name' => $txt_name,
				'txt_phone' => $txt_phone
			);
			
			$this->m_contact->insert_phonebook($ArrInsert);
	
			//NOTE: keluar msg berjaya save
            //echo '<script type="text/javascript">alert("Successfully Added!");</script>';
			$message = array(
				'message'=>'<div class="alert alert-success"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>Successfully added</div>',
			);
			
			$this->session->set_flashdata($message);

			//loading back to listing page
			$data = $this->m_contact->contact_listing();
		
			$this->load->view('home_v', $data);
			//redirect('home/listing/');
		}
		else
		{
			$this->load->view('add_new_v');
		}
	}

	//edit contact function
	public function edit_contact_save()
	{

		$id = $this->input->post('id');
		$txt_name = $this->input->post('txt_name');
		$txt_phone = $this->input->post('txt_phone');

		$ArrUpdate = array(
			'txt_name' => $txt_name,
			'txt_phone' => $txt_phone
		);

		$this->m_contact->update_phonebook_detail($id, $ArrUpdate);

		//NOTE: keluarkan msg berjaya update
		//echo '<script type="text/javascript">alert("Successfully Update!");</script>';

		//loading back to listing page
		$data = $this->m_contact->contact_listing();
		
		$this->load->view('home_v', $data);

	    //redirect('home/listing/');
	}

	//delete
	public function delete_phonebook($id)
	{
		$this->m_contact->delete_phonebook_detail($id);
		redirect(base_url('home/listing/'));
	}

	//user logout 
	function logout()
	{
		session_destroy();
		redirect(base_url('login/contact_login/'));
	}

	
}
